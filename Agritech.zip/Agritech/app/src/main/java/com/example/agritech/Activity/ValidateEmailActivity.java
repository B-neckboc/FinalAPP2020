package com.example.agritech.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.agritech.BaseActivity;
import com.example.agritech.DataManager.PreferencesManager;
import com.example.agritech.Model.CommonValue;
import com.example.agritech.R;
import com.example.agritech.Utils.APIUtils;
import com.example.agritech.Utils.DialogUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;

public class ValidateEmailActivity extends BaseActivity {

    private EditText et_email;
    private Button btnReset;
    public static final String TAG = "AGRITECH_LOGS";
    private DialogUtils dialogUtils;
    private Dialog dialog;
    private Intent intent;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validate_email);
        setTitle("Validate Email");

        init();
    }

    private void init(){
        et_email = findViewById(R.id.et_email);
        btnReset = findViewById(R.id.btnReset);

        btnReset.setOnClickListener(clickListener);
    }

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.btnReset) {
                if (checkFieldInformation()) return;
                dialogUtils = new DialogUtils();
                dialog = dialogUtils.showProgress(ValidateEmailActivity.this, "Validating ...");
                dialog.show();
                validateEmail(et_email.getText().toString());
            }
        }
    };

    private void validateEmail(final String email){
        APIUtils.getAPIService().validateEmail(email).enqueue(new Callback<CommonValue>() {
            @Override
            public void onResponse(Call<CommonValue> call, retrofit2.Response<CommonValue> response) {
                dialog.dismiss();
                if (response.body() != null && response.body().getMessage().equalsIgnoreCase("success")){
                    Log.d(TAG,"response: " + response.body().getMessage());
                    intent = new Intent(ValidateEmailActivity.this, ResetPasswordActivity.class);
                    PreferencesManager.getInstance(ValidateEmailActivity.this).setEmail(email);
                    onStartActivity(intent);
                } else {
                    Toast.makeText(ValidateEmailActivity.this,response.body()!=null ? response.body().getMessage():"Network Fail", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<CommonValue> call, Throwable t) {
                dialog.dismiss();
                Log.e(TAG, "FAIL throwable: " + t.toString());
            }
        });
    }


    private void onStartActivity(Intent intent){
        if(intent!=null){
            finish();
            startActivity(intent);
        }
    }

    private boolean checkFieldInformation(){
        boolean empty = false;

        if (et_email.getText().toString().equalsIgnoreCase("")){
            et_email.setError("fill information");
            empty=true;
        }

        if (emailValidator(et_email.getText().toString().trim())){
            et_email.setError("Invalid Email Address");
            empty=true;
        }

        return empty;
    }

    public boolean emailValidator(String email)
    {
        boolean validate = false;
        String expression = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);

        if (!matcher.matches()) {
            validate = true;
        }

        return validate;
    }

}