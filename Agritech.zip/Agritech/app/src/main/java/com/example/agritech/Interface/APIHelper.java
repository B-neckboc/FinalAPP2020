package com.example.agritech.Interface;

import com.example.agritech.Model.APIResponse;
import com.example.agritech.Model.CommonValue;
import com.example.agritech.Model.ReportData;
import com.example.agritech.Model.UserDetailsInfo;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface APIHelper {

    @Headers({"CONNECT_TIMEOUT:15000", "READ_TIMEOUT:15000", "WRITE_TIMEOUT:15000"})
    @Multipart
    @POST("fileUpload.php")
    Call<APIResponse> uploadImage(@Part MultipartBody.Part file, @Part("file") RequestBody name);

    @POST("mobile_api/login.php")
    @FormUrlEncoded
    Call<UserDetailsInfo> login(@Field("username") String email,
                                @Field("password") String password);

    @POST("mobile_api/registration.php")
    @FormUrlEncoded
    Call<CommonValue> registration(@Field("username") String username,
                                   @Field("email") String email,
                                   @Field("password") String password);

    @POST("mobile_api/validateEmail.php")
    @FormUrlEncoded
    Call<CommonValue> validateEmail(@Field("email") String email);

    @POST("mobile_api/resetPassword.php")
    @FormUrlEncoded
    Call<CommonValue> resetPassword(@Field("email") String email,
                                    @Field("password") String password);

    @GET("mobile_api/reports.php")
    Call<ReportData> getReport();
}