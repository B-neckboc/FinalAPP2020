package com.example.agritech.Activity;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.example.agritech.BaseActivity;
import com.example.agritech.Model.CommonValue;
import com.example.agritech.R;
import com.example.agritech.Utils.APIUtils;
import com.example.agritech.Utils.DialogUtils;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;

public class RegistrationActivity extends BaseActivity {

    private EditText et_username, et_email, et_password, et_confirmpassword;
    private Button registerBtn;
    public static final String TAG = "AGRITECH_LOGS";
    private DialogUtils dialogUtils;
    private Dialog dialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_registration);
        setTitle("Registration");

        init();
    }

    private void init() {
        et_username = findViewById( R.id.et_username);
        et_email = findViewById( R.id.et_email);
        et_password = findViewById( R.id.et_password);
        et_confirmpassword = findViewById( R.id.et_confirmpassword);

        registerBtn = findViewById( R.id.btnSubmit);
        registerBtn.setOnClickListener(clickListener);
    }

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btnSubmit:
                    if (checkFieldInformation()) return;
                    dialogUtils = new DialogUtils();
                    dialog = dialogUtils.showProgress(RegistrationActivity.this, "Registering ...");
                    dialog.show();
                    JSONObject userDetailsInfo = new JSONObject();
                    try {
                        userDetailsInfo.putOpt("username", et_username.getText().toString());
                        userDetailsInfo.putOpt("email", et_email.getText().toString());
                        userDetailsInfo.putOpt("password", et_password.getText().toString());
                        registration(userDetailsInfo);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    };

    private void registration(JSONObject userDetailsInfo){
        APIUtils.getAPIService().registration(userDetailsInfo.optString("username"),userDetailsInfo.optString("email")
                ,userDetailsInfo.optString("password")).enqueue(new Callback<CommonValue>() {
            @Override
            public void onResponse(Call<CommonValue> call, retrofit2.Response<CommonValue> response) {
                dialog.dismiss();
                Log.d(TAG,"response: " + response.body().getMessage());
                Toast.makeText(RegistrationActivity.this,response.body().getMessage(), Toast.LENGTH_LONG).show();
                if (response.body().getMessage().equalsIgnoreCase("success")){
                    finish();
                }
            }

            @Override
            public void onFailure(Call<CommonValue> call, Throwable t) {
                dialog.dismiss();
                Log.e(TAG, "FAIL throwable: " + t.toString());
            }
        });
    }

    private boolean checkFieldInformation(){
        boolean empty = false;

        if (et_username.getText().toString().equalsIgnoreCase("")){
            et_username.setError("fill information");
            empty=true;
        }

        if (et_email.getText().toString().equalsIgnoreCase("")){
            et_email.setError("fill information");
            empty=true;
        }

        if (emailValidator(et_email.getText().toString().trim())){
            et_email.setError("Invalid Email Address");
            empty=true;
        }

        if (et_password.getText().toString().equalsIgnoreCase("")){
            et_password.setError("fill information");
            empty=true;
        }

        if (et_confirmpassword.getText().toString().equalsIgnoreCase("")){
            et_confirmpassword.setError("fill information");
            empty=true;
        } else if (!et_confirmpassword.getText().toString().equalsIgnoreCase(et_password.getText().toString())) {
            et_confirmpassword.setError("Passwords do not match!");
            empty=true;
        }

        return empty;
    }

    public boolean emailValidator(String email)
    {
        boolean validate = false;
        String expression = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);

        if (!matcher.matches()) {
            validate = true;
        }

        return validate;
    }

}