package com.example.agritech.DataManager;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesManager {
    private static final PreferencesManager prefManager = new PreferencesManager();

    private SharedPreferences sharedPref = null;
    private SharedPreferences.Editor editor;

    private PreferencesManager() {}

    public static PreferencesManager getInstance(Context context) {
        if (prefManager.sharedPref == null) {
            prefManager.sharedPref = context.getSharedPreferences("sharedPreference", Context.MODE_PRIVATE);
        }
        return prefManager;
    }


    public int getUserId() {
        return sharedPref.getInt("id", 0);
    }

    public void setUserId(int user_id) {
        editor = sharedPref.edit();
        editor.putInt("id", user_id);
        editor.apply();
    }

    public void setName(String name) {
        editor = sharedPref.edit();
        editor.putString("name", name);
        editor.apply();
    }

    public String getName() {
        return sharedPref.getString("name", "");
    }

    public void setEmail(String email) {
        editor = sharedPref.edit();
        editor.putString("email", email);
        editor.apply();
    }

    public String getEmail() {
        return sharedPref.getString("email", "");
    }

    public void setPassword(String password) {
        editor = sharedPref.edit();
        editor.putString("password", password);
        editor.apply();
    }

    public String getPassword() {
        return sharedPref.getString("password", "");
    }

    public int getNotification() {
        return sharedPref.getInt("notification", 0);
    }

    public void setNotification(int notification) {
        editor = sharedPref.edit();
        editor.putInt("notification", notification);
        editor.apply();
    }

    public int getNotificationNew() {
        return sharedPref.getInt("notificationnew", 0);
    }

    public void setNotificationNew(int notificationnew) {
        editor = sharedPref.edit();
        editor.putInt("notificationnew", notificationnew);
        editor.apply();
    }
}
