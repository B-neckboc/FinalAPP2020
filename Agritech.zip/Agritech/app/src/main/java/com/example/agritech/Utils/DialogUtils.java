package com.example.agritech.Utils;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.example.agritech.R;


public class DialogUtils {

    private Dialog dialog;

    public Dialog showConnectionStatus(Context context) {
        dialog = new Dialog(context,android.R.style.Theme_Translucent_NoTitleBar);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(context, R.color.transparentBlackLight2)));
        dialog.setContentView(R.layout.dialog_connection); // fill layout
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);
        return dialog;
    }

    public Dialog showProgress(Context context, String text) {
        dialog = new Dialog(context,android.R.style.Theme_Translucent_NoTitleBar);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(context,R.color.transparentBlackLight2)));
        dialog.setContentView(R.layout.dialog_progress); // fill layout
        TextView tvProgress = dialog.findViewById(R.id.tv_progress);
        tvProgress.setText(text);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);
        return dialog;
    }
}
