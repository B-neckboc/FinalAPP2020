package com.example.agritech.Model;

import java.util.List;

public class UserDetailsInfo {

    private int UserID;
    private String Username;
    private String Email;
    private String Password;

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int userID) {
        UserID = userID;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    private String value;
    private String message;
    private List<UserDetailsInfo> result;

    public String getValue () {
        return value;
    }

    public String getMessage () {
        return message;
    }

    public List<UserDetailsInfo> getResult() {
        return result;
    }
}
