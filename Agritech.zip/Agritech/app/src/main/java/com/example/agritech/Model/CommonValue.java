package com.example.agritech.Model;

public class CommonValue {

    private String value;
    private String message;

    public String getValue () {
        return value;
    }

    public String getMessage () {
        return message;
    }

}
