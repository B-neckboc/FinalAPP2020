package com.example.agritech.Activity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.agritech.Adapter.ReportAdapter;
import com.example.agritech.BaseActivity;
import com.example.agritech.CustomView.RecyclerViewEmptySupport;
import com.example.agritech.Model.ReportData;
import com.example.agritech.R;
import com.example.agritech.Utils.APIUtils;
import com.example.agritech.Utils.DialogUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends BaseActivity {

    private Context context = this;
    private DialogUtils dialogUtils;
    private Dialog progressDialog;
    private RecyclerViewEmptySupport rvReport;
    private RelativeLayout emptyResult;
    private ReportAdapter reportAdapter;
    private List<ReportData> results = new ArrayList<>();
    private List<ReportData> filterResult = new ArrayList<>();
    public static final String TAG = "AGRITECH_LOGS";
    private ImageView fab_filter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main);

        dialogUtils = new DialogUtils();

        rvReport = findViewById(R.id.rv);
        emptyResult = findViewById(R.id.noResult);

        fab_filter =findViewById(R.id.fab_filter);
        fab_filter.setOnClickListener(clickEvent);

        setRecyclerNotificationAdapter();
        progressDialog = dialogUtils.showProgress(context, "Loading ...");
        progressDialog.show();

        reportAll();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar actions click
        switch (item.getItemId()) {
            case R.id.logout:
                finish();
                return true;
            case R.id.refresh:
                progressDialog = dialogUtils.showProgress(context, "Refreshing ...");
                progressDialog.show();
                reportAll();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private View.OnClickListener clickEvent = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.fab_filter:
                    Calendar calendar = Calendar.getInstance();
                    int year = calendar.get(Calendar.YEAR);
                    int month = calendar.get(Calendar.MONTH);
                    int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

                    DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                            new DatePickerDialog.OnDateSetListener() {
                                @Override
                                public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                    final String filterDate = year + "-" + ((month + 1) < 9 ? "0" + (month + 1) : (month + 1)) + "-" + day;
                                    Toast.makeText(MainActivity.this, filterDate, Toast.LENGTH_LONG).show();
                                    filterReportData(filterDate);
                                }
                            }, year, month, dayOfMonth);

                    datePickerDialog.show();
                    break;
            }
        }
    };

    private void setRecyclerNotificationAdapter() {
        int scrollPosition = 0;
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);

        // If a layout manager has already been set, get current scroll position.
        if (rvReport.getLayoutManager() != null) {
            scrollPosition = ((LinearLayoutManager) rvReport.getLayoutManager())
                    .findFirstCompletelyVisibleItemPosition();
        }

        rvReport.setLayoutManager(mLayoutManager);
        rvReport.scrollToPosition(scrollPosition);
        rvReport.setHasFixedSize(true);

        reportAdapter = new ReportAdapter();
        rvReport.setAdapter(reportAdapter);
        rvReport.setEmptyView(emptyResult);
    }

    private void reportAll() {
        APIUtils.getAPIService().getReport().enqueue(new Callback<ReportData>() {
            @Override
            public void onResponse(Call<ReportData> call, Response<ReportData> response) {
                progressDialog.dismiss();
                if (response.body() != null && response.body().getMessage().equalsIgnoreCase("success")) {
                    Log.d(TAG, "onResponse(): " + response.body().getMessage());
                    results = response.body().getResult();
                    reportAdapter.setList(new ArrayList<>(results));
                    reportAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MainActivity.this,response.body()!=null ? response.body().getMessage():"Network Fail", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ReportData> call, Throwable t) {
                progressDialog.dismiss();
                Log.d(TAG, "onFailure(): " + t.getMessage());
                toastMessage("No Reports");
            }
        });
    }

    private void filterReportData(String filterDate){
        filterResult.clear();
        boolean dataFiltered = true;
        try {
            Date newDate;
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
            for (ReportData reportData : results) {
                newDate = formatter.parse(reportData.getDate_created());
                String newDateFormat = dateformat.format(newDate);
                if (newDateFormat.equalsIgnoreCase(filterDate)) {
                    dataFiltered = false;
                    filterResult.add(reportData);
                    reportAdapter.setList(new ArrayList<>(filterResult));
                    reportAdapter.notifyDataSetChanged();
                }
            }

            if (dataFiltered){
                reportAdapter.setList(new ArrayList<>(filterResult));
                reportAdapter.notifyDataSetChanged();
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private void toastMessage(String Message) {
        Toast.makeText(MainActivity.this, Message, Toast.LENGTH_LONG).show();
    }
}