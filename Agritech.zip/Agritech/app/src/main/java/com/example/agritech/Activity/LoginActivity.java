package com.example.agritech.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.example.agritech.BaseActivity;
import com.example.agritech.DataManager.PreferencesManager;
import com.example.agritech.Model.UserDetailsData;
import com.example.agritech.Model.UserDetailsInfo;
import com.example.agritech.R;
import com.example.agritech.Utils.APIUtils;
import com.example.agritech.Utils.DialogUtils;

import retrofit2.Call;
import retrofit2.Callback;

public class LoginActivity extends BaseActivity {

    private EditText et_username,et_password;
    private Button loginBtn;
    private TextView register, reset;
    public static final String TAG = "AGRITECH_LOGS";
    private DialogUtils dialogUtils;
    private Dialog dialog;
    private Intent intent;
    private static final int WRITE_PERMISSION = 0x01;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        init();
    }

    private void init(){
        et_username = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);

        loginBtn = findViewById(R.id.btnLogin);
        register = findViewById(R.id.tvRegister);
        reset = findViewById(R.id.tvReset);

        loginBtn.setOnClickListener(clickListener);
        register.setOnClickListener(clickListener);
        reset.setOnClickListener(clickListener);
    }

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btnLogin:
                    if (checkFieldInformation()) return;
                    dialogUtils = new DialogUtils();
                    dialog = dialogUtils.showProgress(LoginActivity.this,"Login ...");
                    dialog.show();
                    login(et_username.getText().toString(),et_password.getText().toString());
                    break;
                case R.id.tvRegister:
                    intent = new Intent(LoginActivity.this, RegistrationActivity.class);
                    onStartActivity(intent);
                    break;
                case R.id.tvReset:
                    intent = new Intent(LoginActivity.this, ValidateEmailActivity.class);
                    onStartActivity(intent);
                    break;
            }
        }
    };

    private void login(String username, String password){
        APIUtils.getAPIService().login(username,password).enqueue(new Callback<UserDetailsInfo>() {
            @Override
            public void onResponse(Call<UserDetailsInfo> call, retrofit2.Response<UserDetailsInfo> response) {
                dialog.dismiss();
                if (response.body() != null && response.body().getMessage().equalsIgnoreCase("success")){
                    Log.d(TAG,"response: " + response.body().getMessage() + " result: " + response.body().getResult());
                    for (UserDetailsInfo userDetailsInfo: response.body().getResult()){

                        UserDetailsData.getInstance().setUserDetailsData(userDetailsInfo);

                        PreferencesManager.getInstance(LoginActivity.this).setUserId(userDetailsInfo.getUserID());
                        PreferencesManager.getInstance(LoginActivity.this).setEmail(userDetailsInfo.getEmail());
                        PreferencesManager.getInstance(LoginActivity.this).setPassword(userDetailsInfo.getPassword());

                        intent = new Intent(LoginActivity.this, MainActivity.class);

                        onStartActivity(intent);
                    }
                } else {
                    Toast.makeText(LoginActivity.this,response.body()!=null ? response.body().getMessage():"Network Fail", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<UserDetailsInfo> call, Throwable t) {
                dialog.dismiss();
                Log.e(TAG, "FAIL throwable: " + t.toString());
            }
        });
    }


    private void onStartActivity(Intent intent){
        if(intent!=null){
            startActivity(intent);
        }
    }
    private boolean checkFieldInformation(){
        boolean empty = false;

        if (et_username.getText().toString().equalsIgnoreCase("")){
            et_username.setError("fill information");
            empty=true;
        }
        if (et_password.getText().toString().equalsIgnoreCase("")){
            et_password.setError("fill information");
            empty=true;
        }
        return empty;
    }

}