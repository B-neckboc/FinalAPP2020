package com.example.agritech.Model;

public class UserDetailsData {

    private static UserDetailsData userDetailsData = new UserDetailsData();

    public UserDetailsData(){}

    public static UserDetailsData getInstance(){
        return userDetailsData;
    }

    private int UserID;
    private String Username;
    private String Email;
    private String Password;

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int userID) {
        UserID = userID;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public void setUserDetailsData(UserDetailsInfo userDetailsInfo){
        UserID = userDetailsInfo.getUserID();
        Username = userDetailsInfo.getUsername();
        Email = userDetailsInfo.getEmail();
        Password = userDetailsInfo.getPassword();
    }

}
