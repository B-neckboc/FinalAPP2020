package com.example.agritech.Utils;

import com.example.agritech.Adapter.APICallAdapter;
import com.example.agritech.Interface.APIHelper;

public class APIUtils {

    private APIUtils() {}

    public static final String BASE_URL = "https://technofarmers.000webhostapp.com/";

    public static APIHelper getAPIService() {
        return APICallAdapter.postClient(BASE_URL).create(APIHelper.class);
    }
}