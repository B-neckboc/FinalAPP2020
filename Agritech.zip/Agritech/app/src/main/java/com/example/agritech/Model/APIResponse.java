package com.example.agritech.Model;

import com.google.gson.annotations.SerializedName;

public class APIResponse {

    private boolean success;

    @SerializedName("message")
    private String message;

    public String getMessage() {
        return message;
    }

    public boolean getSuccess() {
        return success;
    }
}
