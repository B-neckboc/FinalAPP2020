package com.example.agritech.Model;

import java.util.List;

public class ReportData {

    private int id;
    private String date_created;
    private String start_status;
    private String start_irrigate;
    private String stop_irrigate;
    private String stop_status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate_created() {
        return date_created;
    }

    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }


    public String getStart_status() {
        return start_status;
    }

    public void setStart_status(String start_status) {
        this.start_status = start_status;
    }

    public String getStart_irrigate() {
        return start_irrigate;
    }

    public void setStart_irrigate(String start_irrigate) {
        this.start_irrigate = start_irrigate;
    }

    public String getStop_irrigate() {
        return stop_irrigate;
    }

    public void setStop_irrigate(String stop_irrigate) {
        this.stop_irrigate = stop_irrigate;
    }

    public String getStop_status() {
        return stop_status;
    }

    public void setStop_status(String stop_status) {
        this.stop_status = stop_status;
    }

    private String value;
    private String message;
    private List<ReportData> result;

    public String getValue () {
        return value;
    }

    public String getMessage () {
        return message;
    }

    public List<ReportData> getResult() {
        return result;
    }
}
