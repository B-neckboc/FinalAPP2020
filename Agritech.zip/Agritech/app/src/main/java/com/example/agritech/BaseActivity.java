package com.example.agritech;

import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.example.agritech.Activity.MainActivity;
import com.example.agritech.DataManager.PreferencesManager;
import com.example.agritech.Service.ConnectionReceiver;
import com.example.agritech.Utils.DialogUtils;

public class BaseActivity extends AppCompatActivity implements ConnectionReceiver.ConnectionReceiverListener {

    private Context context = this;
    private Dialog dialog;
    private ConnectionReceiver connReceiver = null;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        connReceiver = new ConnectionReceiver();
        setConnectionListener(this);

        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(connReceiver, intentFilter);

    }

    public void setConnectionListener(ConnectionReceiver.ConnectionReceiverListener listener) {
        if (connReceiver != null) {
            connReceiver.connectionReceiverListener = listener;
        }
    }

    @Override
    public void onStart(){
        super.onStart();
    }

    @Override
    public void onResume(){
        super.onResume();
        if (connReceiver != null) {
            connReceiver.checkConnection(context);
        }
    }

    @Override
    public void onRestart(){
        super.onRestart();
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        if (dialog != null) {
            dialog.dismiss();
        }

        if (connReceiver != null) {
            unregisterReceiver(connReceiver);
        }

    }

    @Override
    public void onStop(){
        super.onStop();
        if(dialog!=null) {
            dialog.dismiss();
        }
    }

    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {
        if(!isConnected) {
            //show a No Internet Alert or Dialog
            if (dialog == null) {
                DialogUtils dialogUtils = new DialogUtils();
                //hide action_bar_menu bar and status bar
                dialog = dialogUtils.showConnectionStatus(context);
                dialog.setCancelable(false);
                TextView tvHeader = dialog.findViewById(R.id.tv_header);
                tvHeader.setText("No Internet Connection");
                if (!isFinishing()) {
                    dialog.show();
                }
            } else {
                dialog.show();
            }
        }else {
            // dismiss the dialog or refresh the activity
            if (dialog != null) {
                dialog.dismiss();
                dialog = null;
            }

            if (this instanceof MainActivity) {
                if (PreferencesManager.getInstance(this).getNotificationNew() > PreferencesManager.getInstance(this).getNotification()) {
                    showNotification("New Report Update", "Someone reported a hardware.");
                    PreferencesManager.getInstance(this).setNotification(PreferencesManager.getInstance(this).getNotificationNew());
                }
            }
        }
    }

    public void showNotification(String tittle, String data) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 0);

        Notification notification = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.agri_logo)
                .setContentTitle(tittle)
                .setContentText(data)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();

        notification.defaults |= Notification.DEFAULT_VIBRATE;
        notification.defaults |= Notification.DEFAULT_SOUND;

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(0, notification);
    }
}

