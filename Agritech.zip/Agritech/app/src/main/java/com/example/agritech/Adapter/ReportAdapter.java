package com.example.agritech.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.agritech.Model.ReportData;
import com.example.agritech.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ReportAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private ArrayList<ReportData> items = null;
    private Context context;

    public ReportAdapter(){
        if(items == null){
            items = new ArrayList<>();
        }
    }

    public void setList(ArrayList<ReportData> list){
        items = list;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private EditText et_date, et_start_status, et_start_irrigate, et_stop_irrigate, et_stop_status;

        public ViewHolder(View view) {
            super(view);

            et_date = view.findViewById(R.id.et_date);
            et_start_status = view.findViewById(R.id.et_start_status);
            et_start_irrigate = view.findViewById(R.id.et_start_irrigate);
            et_stop_irrigate = view.findViewById(R.id.et_stop_irrigate);
            et_stop_status = view.findViewById(R.id.et_stop_status);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        this.context = viewGroup.getContext();

        View view = LayoutInflater.from(context).inflate(R.layout.adapter_report, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        if (viewHolder instanceof ViewHolder) {
            ViewHolder holder = (ViewHolder) viewHolder;

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {

                Date startIrrigate,stopIrrigate, newDate;
                SimpleDateFormat dateformat = new SimpleDateFormat("EEE, MMM d, ''yy");
                newDate = formatter.parse(items.get(position).getDate_created());
                holder.et_date.setText(dateformat.format(newDate));

                holder.et_start_status.setText(items.get(position).getStart_status());

                SimpleDateFormat timeformat = new SimpleDateFormat("h:mm a");
                startIrrigate = formatter.parse(items.get(position).getStart_irrigate());
                stopIrrigate = formatter.parse(items.get(position).getStop_irrigate());

//                if(items.get(position).getStatus().equalsIgnoreCase("High")){
//                    holder.et_start_irrigate.setTextSize(12f);
//                    holder.et_stop_irrigate.setTextSize(12f);
//                }
//
//                holder.et_start_irrigate.setText(items.get(position).getStatus().equalsIgnoreCase("High")?"Not Irrigated":timeformat.format(startIrrigate));
//                holder.et_stop_irrigate.setText(items.get(position).getStatus().equalsIgnoreCase("High")?"Not Irrigated":timeformat.format(startIrrigate));

                holder.et_start_irrigate.setText(timeformat.format(startIrrigate));
                holder.et_stop_irrigate.setText(timeformat.format(stopIrrigate));

                holder.et_stop_status.setText(items.get(position).getStop_status());

            } catch (ParseException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
