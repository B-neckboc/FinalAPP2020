package com.example.agritech.Activity;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.agritech.BaseActivity;
import com.example.agritech.DataManager.PreferencesManager;
import com.example.agritech.Model.CommonValue;
import com.example.agritech.R;
import com.example.agritech.Utils.APIUtils;
import com.example.agritech.Utils.DialogUtils;

import retrofit2.Call;
import retrofit2.Callback;

public class ResetPasswordActivity extends BaseActivity {

    private EditText et_password, et_confirmpassword;
    private Button btnReset;
    public static final String TAG = "AGRITECH_LOGS";
    private DialogUtils dialogUtils;
    private Dialog dialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
        setTitle("Reset Password");

        init();
    }

    private void init(){
        et_password = findViewById(R.id.et_password);
        et_confirmpassword = findViewById(R.id.et_confirmpassword);
        btnReset = findViewById(R.id.btnReset);

        btnReset.setOnClickListener(clickListener);
    }

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.btnReset) {
                if (checkFieldInformation()) return;
                dialogUtils = new DialogUtils();
                dialog = dialogUtils.showProgress(ResetPasswordActivity.this, "Resetting ...");
                dialog.show();
                resetPassword(et_password.getText().toString());
            }
        }
    };

    private void resetPassword(String password){
        APIUtils.getAPIService().resetPassword(PreferencesManager.getInstance(this).getEmail(),password).enqueue(new Callback<CommonValue>() {
            @Override
            public void onResponse(Call<CommonValue> call, retrofit2.Response<CommonValue> response) {
                dialog.dismiss();
                if (response.body() != null && response.body().getMessage().equalsIgnoreCase("success")){
                    Log.d(TAG,"response: " + response.body().getMessage());
                    Toast.makeText(ResetPasswordActivity.this,response.body().getMessage(), Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    Toast.makeText(ResetPasswordActivity.this,response.body()!=null ? response.body().getMessage():"Network Fail", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<CommonValue> call, Throwable t) {
                dialog.dismiss();
                Log.e(TAG, "FAIL throwable: " + t.toString());
            }
        });
    }

    private boolean checkFieldInformation(){
        boolean empty = false;

        if (et_password.getText().toString().equalsIgnoreCase("")){
            et_password.setError("fill information");
            empty=true;
        }

        if (et_confirmpassword.getText().toString().equalsIgnoreCase("")){
            et_confirmpassword.setError("fill information");
            empty=true;
        }

        if (!et_confirmpassword.getText().toString().equalsIgnoreCase(et_password.getText().toString().trim())) {
            et_confirmpassword.setError("Passwords do not match!");
            empty=true;
        }

        return empty;
    }

}